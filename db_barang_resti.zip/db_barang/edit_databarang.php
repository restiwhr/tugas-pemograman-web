<!DOCTYPE html>
<html>
<head>
<title>DATA BARANG</title>
</head>
<body>
<h2>DATA MAHASISWA</h2>
<br/>
<a href="index.php">KEMBALI</a>
<br/>
<br/>
<h3>EDIT DATA BARANG</h3>
<?php
include 'koneksi.php';
$id = $_GET['id'];
$data = mysqli_query($koneksi,"select * from dbbarang where kode barang='$id'");
while($d = mysqli_fetch_array($data)){
?>
<form method="post" action="prosesupdate.php"
enctype="multipart/form-data">
<table>
<tr>
<td>kode barang</td>
<td>
<input type="text" name="kode barang" value="<?php echo 
$d['kode barang']; ?>" readonly>
</td>
</tr>

<tr>
<td>nama barang</td>
<td><input type="text" name="nama barang" value="<?php echo 
$d['nama barang']; ?>"></td>
</tr>
<tr>
<td>satuan</td>
<td><input type="number" name="satuan" value="<?php echo 
$d['satuan']; ?>"></td>

</tr>
<tr>
<td>kategori</td>
<td>
<Select name=kategori>
<option value="alat pembersih" <?php if($d['kategori']=="pembersih") echo 
'selected="selected"'; ?> >alat pembersih</option>
<option value="peralatan dapur" <?php if($d['kategori']=="dapur") echo 
'selected="selected"'; ?> >peralatan dapur</option>
<option value="peralatan kamar tidur" <?php if($d['kategori']=="kamar tidur") echo 
'selected="selected"'; ?> >peralatan kamar tidur</option>
</select>
</td>
</tr>
<tr>
<td>harga modal</td>
<td><input type="number" name="harga modal" value="<?php echo 
$d['harga modal']; ?>"></td>
</tr>
<tr>
<td>harga jual</td>
<td><input type="number" name="harga jual" value="<?php echo 
$d['harga jual']; ?>"></td>
</tr>
<tr>
<td>gambar</td>
<td><input type="file" name="file"> <img src="file/<?php echo 
$d['gambar']; ?>" style="width: 100px;float: left;margin-bottom: 5px;">

<br/><i style="float: left;font-size: 11px;color: 
red">Abaikan jika tidak merubah photo</i>
</td>
</tr>
<tr>
<td></td>
<td>
<br/><br/>
<input name="BtnSimpan" type="submit" value="SIMPAN">
<input name="BtnBatal" type="reset" value="BATAL" />
</td>
</tr>
</table>
</form>
<?php
}
?>
</body>
</html>