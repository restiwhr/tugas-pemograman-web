<?php
if(isset($_GET['id'])){
include('koneksi.php');
$npm=$_GET['id'];
$del=mysqli_query($koneksi,"DELETE FROM tbbarang WHERE
kode barang='$kode'");
if($del){
echo'Data barang berhasil dihapus! ';
echo'<a href="index.php">Kembali</a>';
}else{
echo'Gagal menghapus data! ';
echo'<a href="index.php">Kembali</a>';
}
}
?>